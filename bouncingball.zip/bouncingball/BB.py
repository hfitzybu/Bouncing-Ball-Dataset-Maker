import os

import numpy as np
import random as r
import cv2

from config import *
class Ball:
    def __init__(self, x, y, radius, dx, dy):
        self.x = x
        self.y = y
        self.dx = dx
        self.dy = dy
        self.radius = radius
        self.hit_h_wall = 0
        self.hit_v_wall = 0
        self.last_collision = -1


def distance(obj1, obj2):
    return ((obj1.x - obj2.x) ** 2 + (obj1.y - obj2.y) ** 2) ** 0.5


def norm(vector):
    return (vector[0] ** 2 + vector[1] ** 2) ** 0.5


def plot_ball(ball, map):
    X, Y = np.meshgrid(np.arange(WINDOW_WIDTH), np.arange(WINDOW_HEIGHT))
    dist = (X - ball.x) ** 2 + (Y - ball.y) ** 2
    map[np.where(dist < ball.radius ** 2)] = 255
    return map


def to_video(map, filename):
    print('test')
    # image_list = []
    # for i in range(times):
    #     image_list.append(Image.fromarray(map[i, :, :].astype('uint8')).convert('L'))
    filename = filename + '.mp4'
    size = [WINDOW_WIDTH, WINDOW_HEIGHT]
    fps = 5
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(filename, fourcc, fps, size, False)
    for i in range(times):
        # out.write(image_list[i])
        out.write(map[i, :, :])
        # print('test')
    out.release()


def create_objects(NUM_OBJ, default_radius=25, speed_width=[-4, 4]):
    objects = []

    rads=np.zeros((1,NUM_OBJ,2))
    for _ in range(NUM_OBJ):
        radius = default_radius
        x = r.randint(radius, WINDOW_WIDTH - radius)
        y = r.randint(radius, WINDOW_HEIGHT - radius)
        if len(objects) != 0:
            state = True
            cur_length = len(objects)
            actual_dis = np.zeros(cur_length)
            dis = np.zeros(cur_length)  # dis should less than acutal_dis to avoid overlap
            while state:
                state = False
                for i in range(cur_length):
                    obj = objects[i]
                    actual_dis[i] = (obj.x - x) ** 2 + (obj.y - y) ** 2
                    dis[i] = (radius + obj.radius) ** 2
                    if sum(actual_dis < dis) > 0:
                        state = True
                        x = r.randint(radius, WINDOW_WIDTH - radius)
                        y = r.randint(radius, WINDOW_HEIGHT - radius)
        #dx = r.randint(speed_width[0], speed_width[1])
        #dy = r.randint(speed_width[0], speed_width[1])
        dx = 0
        dy = 0
        while dx==0:
            dx = r.randint(speed_width[0], speed_width[1])
        while dy==0:
            dy = r.randint(speed_width[0], speed_width[1])
        objects.append(Ball(x, y, radius, dx, dy))
        # rads.append([x,y])
        rads[0,_,0]=x
        rads[0,_,1]=y

    return objects,rads


def animation():
    objects,rads_init = create_objects(NUM_OBJ, default_radius, speed_width)

    centers=np.zeros((times,NUM_OBJ,2))
    # centers[0]=rads_init
    # print(rads)
    # 1 I 2
    # T I 2
    # input('')
    map = np.zeros([times, WINDOW_WIDTH, WINDOW_HEIGHT], dtype=np.uint8)
    for obj in objects:
        map[0, :, :] = plot_ball(obj, map[0, :, :])
    for i in range(1, times):

        ball_index=0
        for obj in objects:  # Moving each object
            obj.x += obj.dx
            obj.y += obj.dy
            centers[i,ball_index]=[obj.x,obj.y]
            ball_index=ball_index+1
            # print('obj: ({},{})'.format(obj.dx, obj.dy))
            map[i, :, :] = plot_ball(obj, map[i, :, :])

            # check vertical wall collision
            if obj.x <= obj.radius:
                obj.dx = abs(obj.dx)
            elif obj.x >= WINDOW_WIDTH - obj.radius:
                obj.dx = - abs(obj.dx)

            # check horizontal wall collision
            if obj.y <= obj.radius:
                obj.dy = abs(obj.dy)
            elif obj.y >= WINDOW_HEIGHT - obj.radius:
                obj.dy = - abs(obj.dy)

        for index in range(len(objects)):
            for j in range(index, len(objects)):
                obj1 = objects[index]
                obj2 = objects[j]
                dist = distance(obj1, obj2)
                if dist <= (obj1.radius + obj2.radius):
                    obj1.dx, obj2.dx = obj2.dx, obj1.dx
                    obj1.dy, obj2.dy = obj2.dy, obj1.dy

    return map,centers

