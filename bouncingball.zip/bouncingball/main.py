import numpy as np

from utils.event_utils import *
from utils.utilsybu import *
from BB import *

def main():

    for i in range(SAMPLES):
        print('sample:' , i)

        output_this,centers = animation() # T H W, T ball_num 2

        centers=centers.astype(np.int32) # [T, H, W]

        events = gray2event_(output_this,gap=1) # [T, 2, H, W]
        events5 = gray2event_(output_this,gap=5) # [T, 2, H, W]


        save_path='saved/BALL'+str(NUM_OBJ)+'/'+ str(i).zfill(4)
        # save_path='saved/BALL3/'+ str(i).zfill(4)
        # save_path='saved/BALL5/'+ str(i).zfill(4)
        print(save_path)
        #output,centerss #B T H W, B T ball_num 2

        en,noise = add_noise(events, thresh=1 - 1e-3)

        # noise_num=np.sum(noise)
        # active_num=np.sum(events)
        # print('noise_num',noise_num)
        # print('active_num',active_num) # 27.7%
        # print(noise_num/active_num)

        # pause()
        events_binary = np.where(events>0,True,False)
        en_binary = np.where(en>0,True,False)

        if not os.path.exists(save_path):
            os.makedirs(save_path)
            os.makedirs(save_path+'/rgb')
            os.makedirs(save_path+'/rgb5')
            os.makedirs(save_path+'/rgb_noised')
            print('make ',save_path)

        rgb_noise = event2rgb_(en)
        rgb = event2rgb_(events)
        rgb5 = event2rgb_(events5)

        for j in range(rgb.shape[0]):
            cv2.imwrite(save_path+'/rgb/'+str(j).zfill(4)+'.png',rgb[j])
            cv2.imwrite(save_path+'/rgb_noised/'+str(j).zfill(4)+'.png',rgb_noise[j])

        for j in range(rgb5.shape[0]):
            cv2.imwrite(save_path + '/rgb5/' + str(5*j).zfill(4) + '.png', rgb5[j])

        events_path=os.path.join(save_path,'events.npy')
        np.save(events_path,events_binary)

        bb_path=os.path.join(save_path,'bb.npy')
        np.save(bb_path,centers)

        gray_path=os.path.join(save_path,'gray.npy')
        np.save(gray_path,output_this)

        events_p=os.path.join(save_path,'en.npy')
        np.save(events_p,en_binary)



def main0():
    output = np.zeros([SAMPLES, times, WINDOW_WIDTH, WINDOW_HEIGHT], dtype=np.uint8)
    file_name = '{}ball_{}frames_{}width_{}height_{}speed'.format(NUM_OBJ, times, WINDOW_WIDTH, WINDOW_HEIGHT, SPEED_LIMIT)
    dir = '/data2/Projects/zhenhang/bouncing ball/'
    file_path = os.path.join(dir, file_name)
    centerss=np.zeros((SAMPLES,times,NUM_OBJ,2))
    for i in range(SAMPLES):
        output[i],centers = animation() # T H W, T ball_num 2
        centerss[i]=centers
        # print(output[i].shape)
        # print(centers)
        # pause()
        print('next sample:' , i)
    centerss=centerss.astype(np.int32) # [B, T, H, W]
    events = gray2event(output) # [B, T, 2, H, W]
    # pause()

    # en,_=add_noise(events[0],thresh=1-1e-3)
    # rgb=event2rgb_(events[0])
    # rgb=event2rgb_(en)
    # for i in range(rgb.shape[0]):
    #
    #     show=rgb[i]
    #     for j in range(NUM_OBJ):
    #         p1=[centerss[0,i,j,0]-default_radius,centerss[0,i,j,1]-default_radius]
    #         p2=[centerss[0,i,j,0]+default_radius,centerss[0,i,j,1]+default_radius]
    #         show=cv2.rectangle(show,p1,p2,color=[0,0,0])
    #     cv2.imshow('X',show)
    #     cv2.waitKey(100)
    #
    # pause()
    for i in range(output.shape[0]):
        save_path='saved/BALL3/'+ str(i).zfill(4)
        print(save_path)
        #output,centerss #B T H W, B T ball_num 2

        en,noise = add_noise(events[0], thresh=1 - 1e-3)

        noise_num=np.sum(noise)
        active_num=np.sum(events[0])

        print('noise_num',noise_num)
        print('active_num',active_num) # 27.7%
        print(noise_num/active_num)

        # pause()
        events_binary = np.where(events[0]>0,True,False)
        en_binary = np.where(en>0,True,False)

        if not os.path.exists(save_path):
            os.makedirs(save_path)
            os.makedirs(save_path+'/rgb')
            os.makedirs(save_path+'/rgb_noised')
            print('make ',save_path)

        rgb_noise = event2rgb_(en)
        rgb = event2rgb_(events[i])

        for j in range(rgb.shape[0]):
            cv2.imwrite(save_path+'/rgb/'+str(j).zfill(4)+'.png',rgb[j])
        for j in range(rgb.shape[0]):
            cv2.imwrite(save_path+'/rgb_noised/'+str(j).zfill(4)+'.png',rgb_noise[j])

        events_path=os.path.join(save_path,'events.npy')
        np.save(events_path,events_binary)

        bb_path=os.path.join(save_path,'bb.npy')
        np.save(bb_path,centerss[i])

        gray_path=os.path.join(save_path,'gray.npy')
        np.save(gray_path,output[i])

        events_p=os.path.join(save_path,'en.npy')
        np.save(events_p,en_binary)




    pause()
    np.save(file_path, output)
    print(output[8])
    # to_video(output[8],'8')
    # to_video(output[88],'88')
    # to_video(output[888],'888')

if __name__ == '__main__':
    main()
    # a = np.load('3ball_3000steps_50_50.npy')
    # for i in range(55):
    #     plt.imshow(a[i, :, :], cmap='gray')
    #     plt.show()
    #     plt.close()